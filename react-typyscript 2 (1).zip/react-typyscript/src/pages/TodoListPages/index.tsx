import { url } from "inspector";
import Todos from "../../components/Todos";

const TodoListPages = () => {
    return (
        <div>
            <Todos/>
        </div>
    );
};

export default TodoListPages;