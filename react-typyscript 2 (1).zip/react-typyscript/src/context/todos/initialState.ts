export default {
    todos: [],
    loading: false,
    isEdit: false,
    error: null
}