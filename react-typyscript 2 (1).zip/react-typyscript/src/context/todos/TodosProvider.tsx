import React, { createContext, useReducer } from 'react';
import initialState from './initialState';
import reducer from './reducer';

export type TTodosContext = {
    todos: any[];
    loading: boolean;
    isEdit: boolean;
    error: unknown;
}

export const todosContext = createContext<TTodosContext>(initialState)

const TodosProvider = ({ children }: React.PropsWithChildren) => {

    const [todosStore, dispatch] = useReducer(reducer, initialState)

    const value: TTodosContext = {
        ...todosStore
    }

    return (
        <todosContext.Provider
            value={value}
        >
            {children}
        </todosContext.Provider>
    );
};

export default TodosProvider;