import React from 'react';
import { AppButton, AppInput } from '../../../UI';

const TodoForm = () => {
    return (
        <form style={{display:"flex", justifyContent:"center"}}>
            <AppInput placeholder='Текст' style={{width:"20%", outline:"none", borderRadius:"8px", padding:"5px", border:"1px solid grey", background:"rgba(0, 0, 0, 0.7)", fontSize:"80%", color:"white"}}/>
            <AppButton>Добавить</AppButton>
        </form>
    );
};

export default TodoForm;