
const TodoList = () => {

    return (
        <ul style={{position:'absolute', left:"50%", transform:"translate(-50%)", listStyle:"none", width:"40%", padding:"1%",textAlign:"center", boxShadow:"0px 0px 3px 0.5px black", borderRadius:"22px", backgroundColor:" rgba(255, 255, 255, 0.2)", fontSize:"100%", textAlignLast:"center"}}>

        </ul>  
    );
};

export default TodoList;