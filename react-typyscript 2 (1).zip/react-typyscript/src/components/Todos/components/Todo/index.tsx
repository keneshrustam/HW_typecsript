import React from 'react';

const Todo = () => {
    return (
        <li style={{width:"90%", boxShadow:"0px 0px 3px 0.5px black", display:"inline-block", borderRadius:"16px", padding:"1.5%", marginBottom:"3%", backgroundColor:"#000507", color:"white"}}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur, dolores?
        </li>
    );
};

export default Todo;