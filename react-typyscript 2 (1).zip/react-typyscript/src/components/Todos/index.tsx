import { TodoForm, TodoList } from "./components"

const Todos = () => {
    return (
        <div>
            <h1 style={{fontSize:"150%", color:"white", textAlign: "center"}}>Todo Application</h1>
            <TodoForm/>
            <TodoList/>
        </div>
    )
}

export default Todos