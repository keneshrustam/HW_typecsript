import Input from "./Input";
import Button from "./Button";


export {
    Input as AppInput,
    Button as AppButton
}