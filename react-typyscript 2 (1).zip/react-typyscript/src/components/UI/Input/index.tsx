import React from 'react'

const Input = ( props : any ) => {
    return (
        <input
            {...props}
        />
    )
}

export default Input