import React from 'react';

const Button = ({ children } : React.PropsWithChildren ) => {
    return (
        <button  style={{borderRadius:"8px", border:"1px solid grey", fontSize:"85%", backgroundColor:"#000507", color:"white"}}>
            {children} 
        </button>
    );
};

export default Button;